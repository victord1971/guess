
#include "widget.h"
#include <QApplication>
Widget* appl1;

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QTranslator trans;

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    qDebug() << "Element" << qrand();

    trans.load("appl_Uk.qm",".");
    qApp->installTranslator(&trans);

    appl1=new Widget;
    appl1->setWindowTitle("4-4");
    appl1->resize(640,550);
    appl1->show();
    return app.exec();
}
