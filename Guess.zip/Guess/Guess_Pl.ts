<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>QObject</name>
    <message>
        <location filename="widget.cpp" line="86"/>
        <source>Compare this number with your number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="93"/>
        <source>Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="96"/>
        <source>the quantity of digits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="99"/>
        <source>that the program correctly predicted:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="109"/>
        <source>How many of them</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="112"/>
        <source>stands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="115"/>
        <source>in its place?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="123"/>
        <source>Take a number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="126"/>
        <source>consisting of four</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="129"/>
        <source>different digits.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="132"/>
        <source>And I&apos;m going to guess your number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="139"/>
        <source>Error. Check your moves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="146"/>
        <source>Play again?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.cpp" line="151"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="153"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.cpp" line="155"/>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
