<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>QObject</name>
    <message>
        <location filename="widget.cpp" line="86"/>
        <source>Compare this number with your number:</source>
        <translation type="unfinished">Compare this number with your number:</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="93"/>
        <source>Enter</source>
        <translation type="unfinished">Enter</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="96"/>
        <source>the quantity of digits</source>
        <translation type="unfinished">the quantity of digits</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="99"/>
        <source>that the program correctly predicted:</source>
        <translation type="unfinished">that the program correctly predicted:</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="109"/>
        <source>How many of them</source>
        <translation type="unfinished">How many of them</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="112"/>
        <source>stands</source>
        <translation type="unfinished">stands</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="115"/>
        <source>in its place?</source>
        <translation type="unfinished">in its place?</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="123"/>
        <source>Take a number</source>
        <translation type="unfinished">Take a number</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="126"/>
        <source>consisting of four</source>
        <translation type="unfinished">consisting of four</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="129"/>
        <source>different digits.</source>
        <translation type="unfinished">different digits.</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="132"/>
        <source>And I&apos;m going to guess your number</source>
        <translation type="unfinished">And I&apos;m going to guess your number</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="139"/>
        <source>Error. Check your moves</source>
        <translation type="unfinished">Error. Check your moves</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="146"/>
        <source>Play again?</source>
        <translation type="unfinished">Play again?</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.cpp" line="151"/>
        <source>Start</source>
        <translation type="unfinished">Start</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="153"/>
        <source>Next</source>
        <translation type="unfinished">Next</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="155"/>
        <source>More</source>
        <translation type="unfinished">More</translation>
    </message>
</context>
</TS>
