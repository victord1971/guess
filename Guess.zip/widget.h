#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTranslator>
#include <QFrame>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QIntValidator>
#include <QTableWidget>
#include <QBoxLayout>
#include <QDebug>
#include <QtGui>  //for installTranslator

extern class Widget* appl1;
//extern class Widget* appl2;

class Widget : public QWidget
{
    Q_OBJECT
private:
    QFrame*      fr1;
    QFrame*      fr2;
    QFrame*      fr21;
    QFrame*      fr22;
    QFrame*      fr20;
    QLabel*      llll;
    QLabel*      l_compa_m;
    QLabel*      l_compare;
    QLabel*      l_comp1_5;
    QLabel*      l_compar2;
    QLabel*      l_try;
    QLabel*      l_error;
    QLabel*      l_more;
    QPushButton* bttnStart;
    QPushButton* bttnNext;
    QPushButton* bttnMore;
    QPushButton* bttnUk;
    QPushButton* bttnEn;
    QPushButton* bttnPl;
    QLineEdit*   le1;
    QLineEdit*   le2;
    QIntValidator*  validator;
    QIntValidator*  validato2;

    QTableWidget* table;
    QStringList* listTable;
    QString* startString;
    QPixmap* pixUk;
    QPixmap* pixEn;
    QPixmap* pixPl;
    void appl1F();
    void appl2F();
public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
//*
public slots:
    void slotStartClicked();
    void slotNextClicked();
    void slotMoreClicked();
    void slotUkClicked();
    void slotEnClicked();
    void slotPlClicked();
    void selectionChanged21();
    void selectionChanged22();
    void textEdited21();
    void textEdited22();//
};
#endif // WIDGET_H
