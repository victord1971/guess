<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk_UA">
<context>
    <name>QObject</name>
    <message>
        <location filename="widget.cpp" line="86"/>
        <source>Compare this number with your number:</source>
        <translation type="unfinished">Порівняйте це число з Вашим числом:</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="93"/>
        <source>Enter</source>
        <translation type="unfinished">Введіть</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="96"/>
        <source>the quantity of digits</source>
        <translation type="unfinished">кількість цифр,</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="99"/>
        <source>that the program correctly predicted:</source>
        <translation type="unfinished">що вгадано програмою</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="109"/>
        <source>How many of them</source>
        <translation type="unfinished">Скільки з них</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="112"/>
        <source>stands</source>
        <translation type="unfinished">стоїть</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="115"/>
        <source>in its place?</source>
        <translation type="unfinished">на своєму місці</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="123"/>
        <source>Take a number</source>
        <translation type="unfinished">Загадайте число,</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="126"/>
        <source>consisting of four</source>
        <translation type="unfinished">яке містить </translation>
    </message>
    <message>
        <location filename="widget.cpp" line="129"/>
        <source>different digits.</source>
        <translation type="unfinished">чотири різні цифри</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="132"/>
        <source>And I&apos;m going to guess your number</source>
        <translation type="unfinished">А я спробую його вгадати</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="139"/>
        <source>Error. Check your moves</source>
        <translation type="unfinished">Помилка. Перевірте всі попередні кроки</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="146"/>
        <source>Play again?</source>
        <translation type="unfinished">Граємо ще?</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.cpp" line="151"/>
        <source>Start</source>
        <translation type="unfinished">Вогонь!</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="153"/>
        <source>Next</source>
        <translation type="unfinished">Далі</translation>
    </message>
    <message>
        <location filename="widget.cpp" line="155"/>
        <source>More</source>
        <translation type="unfinished">Грати ще</translation>
    </message>
</context>
</TS>
